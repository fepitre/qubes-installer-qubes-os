.. Blivet documentation master file, created by
   sphinx-quickstart on Wed Sep 18 14:37:01 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Blivet's documentation!
==================================

Contents:

.. toctree::
   :maxdepth: 1

   intro
   api
   testing
   blivet/blivet
   tests/tests

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

