events
=======

* :mod:`~blivet.events.manager`
    * :data:`~blivet.events.manager.event_manager`
        * :meth:`~blivet.events.manager.UdevEventManager.disable`
        * :meth:`~blivet.events.manager.UdevEventManager.enable`
        * :attr:`~blivet.events.manager.UdevEventManager.enabled`
        * :attr:`~blivet.events.manager.EventManager.error_cb`
        * :attr:`~blivet.events.manager.EventManager.notify_cb`
